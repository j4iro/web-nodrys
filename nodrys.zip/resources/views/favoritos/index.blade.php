@extends('layouts.app')

@section('content')
<div class="container">

    <div class="row mt-3">
        <div class="col-12 ">
            <h2>Mis Restaurantes o platos favoritos</h2>
        </div>
    </div>

    {{-- <div class="row mt-3">
        <div class="col-12 ">
            
            <table class="table table-responsive table-hover">
                <thead class="thead-light">
                    <tr>
                    <th scope="col">Imagen</th>
                    <th scope="col">Tipo</th>
                    <th scope="col">Plato</th>
                    <th scope="col">Precio</th>
                    <th scope="col">Cantidad</th>
                    <th scope="col">Sub Total</th>
                    <th scope="col">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                    <th scope="row">1</th>
                    <td>Segundo</td>
                    <td>Cuy Asado</td>
                    <td>25.00</td>
                    <td><input type="number" class="form-control form-control-sm" name="cantidad[]" value="1"></td>
                    <th scope="row">25.00</th>
                    <td><a href="" class="btn btn-danger btn-sm">Eliminar</a></td>
                    </tr>
                </tbody>
            </table>

        </div>
    </div> --}}



</div>
@endsection