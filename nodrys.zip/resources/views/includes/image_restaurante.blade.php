
<img src="{{ route('restaurant.image',['filename'=>$restaurant->image]) }}" class="card-img-top img-card-restaurant" alt="Foto de {{$restaurant->name}} en Nodrys">
