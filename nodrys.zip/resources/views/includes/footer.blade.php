<footer class="footer mt-4">
    <div class="container-fluid bg-dark ">
        <div class="row py-3">
            <div class="col-12 text-center">
                <p class="font-weight-bold text-light">2019 | Team 1</p>
            </div>
        </div>

    </div>
</footer>
