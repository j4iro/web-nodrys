<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Asigned_role extends Model
{
    protected $table = 'asigned_roles';
}
