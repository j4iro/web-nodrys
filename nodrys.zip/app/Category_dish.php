<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Category_dish extends Model
{
    protected $table = 'categories_dishes';
}
