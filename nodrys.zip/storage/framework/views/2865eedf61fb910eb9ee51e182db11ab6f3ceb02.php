<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Reporte - Historial de platos</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/pdf.css')); ?>">
</head>
<body>
    <div class="container-fluid">

        <img class="encabezado" src="<?php echo e(asset('images/favicon/favicon.png')); ?>" width="50">
        <center>
            <strong >Historial de mis platos</strong>
        </center>

            <table>
                <thead class="bg-plomo">
                    <tr>
                        <th>#</th>
                        <th>Nombre</th>
                        <th>Preparación</th>
                        <th>Precio</th>
                        <th>Creación</th>
                        <th>Categoria</th>
                    </tr>
                </thead>

                <tbody>

                    <?php $cantidad=0; ?>

                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $cantidad++; ?>
                            <tr>
                            <th><?php echo e($cantidad); ?></th>
                            <td><?php echo e($plato->name); ?></td>
                            <td><?php echo e($plato->time); ?> Min.</td>
                            <td><?php echo e($plato->price); ?></td>
                            <td><?php echo e($plato->created_at); ?></td>
                            <td><?php echo e($plato->categoria); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>

              <table class="w-50">
                <thead class="bg-plomo">
                    <tr>
                        <th colspan="2">Resultados</th>
                    </tr>
                </thead>

                <tbody>
                    <tr>
                        <th class="text-left">Fecha de impresión :</th>
                        <td><?php echo e($date); ?></td>
                    </tr>
                    <tr>
                        <th class="text-left">Total de registros   : </th>
                        <td><?php echo e($cantidad); ?></td>
                    </tr>
                </tbody>

            </table>

</body>
</html>
