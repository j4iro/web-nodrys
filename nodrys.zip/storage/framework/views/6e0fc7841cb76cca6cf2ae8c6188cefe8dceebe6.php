<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Reporte Pedidos</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/pdf.css')); ?>">
</head>
<body>
    <div class="container-fluid">
    <img class="encabezado" src="<?php echo e(asset('images/favicon/favicon.png')); ?>" width="50">
    <center>
    <strong>Reporte pedidos de <?php echo e($data2[0]); ?> a <?php echo e($data2[1]); ?></strong>
    </center>

        <table >
            <thead class="bg-plomo">
                <tr>
                    <th>Item</th>
                    <th>Fecha</th>
                    <th>Hora</th>
                    <th>Estado</th>
                    <th>Ocasión Especial</th>
                    <th>Cliente</th>
                    <th>Distrito</th>
                </tr>
            </thead>

            <tbody>

                <?php $cantidad=0; ?>

                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $cantidad++; ?>
                        <tr>
                        <th><?php echo e($cantidad); ?></th>
                        <td class="text-center"><?php echo e($cliente->date); ?></td>
                        <td class="text-center"><?php echo e($cliente->hour); ?></td>
                        <td class="text-center"><?php echo e($cliente->state); ?></td>
                        <td class="text-center"><?php echo e($cliente->oca_special); ?></td>
                        <td class="text-center"><?php echo e($cliente->nombre_c); ?> <?php echo e($cliente->apellido_c); ?></td>
                        <td class="text-center"><?php echo e($cliente->distrito); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>

    <table class="w-50" >
        <thead class="bg-plomo" >
            <tr><th colspan="2">Resultados</th></tr>
        </thead>

        <tbody>
            <tr>
                <th class="text-left" >Fecha de impresión  :</th>
                <td><?php echo e($date); ?></td>
            </tr>
            <tr>
                <th class="text-left" >Total de registros   : </th>
                <td><?php echo e($cantidad); ?></td>
            </tr>
        </tbody>

    </table>

</body>
</html>
