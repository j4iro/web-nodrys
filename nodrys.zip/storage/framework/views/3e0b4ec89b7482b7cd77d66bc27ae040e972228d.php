<?php $__env->startSection('content'); ?>


<div class="col-6 ">

    <?php if(session('message')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>¡Genial!</strong> Tus datos se han guardado correctamente.
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin-r.cuentaBancaria.save')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

    <div class="card shadow">
    <div class="card-header"><strong>Configuración de mi cuenta bancaria</strong></div>

        <div class="card-body">
                <div class="row mt-2">
                        <div class="col-12">
                            <input type="checkbox" class="d-none" name="pagarcontarjeta" id="checkpagarcontarjeta">
                            <input type="text" placeholder="Número de tarjeta" class="form-control" name="num_card" value="<?php echo e($card->num_card ?? ''); ?>" id="num_card" autofocus>
                        </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-12">
                            <input type="text" placeholder="Nombre en la tarjeta" class="form-control" value="<?php echo e($card->owner ?? ''); ?>" name="owner" id="owner" >
                        </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-8 ">
                            <select name="country" class="form-control" id="country">
                                <option value="" disabled selected>Pais</option>
                                <option value="per" <?php if(isset($card->country) && "per"==$card->country): ?> <?php echo e('selected'); ?> <?php endif; ?> >Perú</option>
                                <option value="col" <?php if(isset($card->country) && "col"==$card->country): ?> <?php echo e('selected'); ?> <?php endif; ?> >Colombia</option>
                                <option value="chi" <?php if(isset($card->country) && "chi"==$card->country): ?> <?php echo e('selected'); ?> <?php endif; ?> >Chile</option>
                                <option value="ecu" <?php if(isset($card->country) && "ecu"==$card->country): ?> <?php echo e('selected'); ?> <?php endif; ?> >Ecuador</option>
                                <option value="mex" <?php if(isset($card->country) && "mex"==$card->country): ?> <?php echo e('selected'); ?> <?php endif; ?> >México</option>
                            </select>
                        </div>
                        <div class="col-4">
                            <input  placeholder="Código Postal" type="number" class="form-control" value="<?php echo e($card->cod_postal ?? ''); ?>" name="cod_postal" id="cod_postal">
                        </div>
                    </div>

                    <?php if(isset($card->id)): ?>
                        <input type="hidden" name="action" value="editar">
                        <input type="hidden" name="id_card" value="<?php echo e($card->id ?? ''); ?>">
                    <?php else: ?>
                        <input type="hidden" name="action" value="guardar">
                    <?php endif; ?>

                    <div class="row mt-4 ">
                        <div class="col-12">
                            <button type="submit" class="btn btn-danger btn-block ">Guardar Cambios</button>
                        </div>
                    </div>

        </div>

    </div>
    </div>
</div>

</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-r', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>