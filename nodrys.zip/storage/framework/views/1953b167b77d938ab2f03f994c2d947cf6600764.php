<?php $__env->startSection('content'); ?>
    <div class="container-fluid ">
    <form action="<?php echo e(route('admin.categorias.save')); ?>" method="post" enctype="multipart/form-data">

    <!--Formulario de Registro-->
    <div class="row ">

    <div class="col-12 col-md-9 col-lg-8 mb-3">

    <div class="card shadow p-4 ">

        <div class="row">
            <dt class="col-12">
                <?php if(isset($categorias)): ?>
                    Editar categoria
                    <input type="hidden" name="editar" value="editar">
                    <input type="hidden" name="id" value="<?php echo e($categorias->id ?? ''); ?>">
                <?php else: ?>
                    Nuevo categoria
                    <input type="hidden" name="editar" value="agregar">
                <?php endif; ?>


                <hr>
            </dt>
        </div>
        <div class="row">
            <div class="col-12">
                <?php if(session('resultado')): ?>
                    <strong>
                        <div class="alert alert-success"><?php echo e(session('resultado')); ?></div>
                    </strong>
                <?php endif; ?>
            </div>
        </div>

            <?php echo e(csrf_field()); ?>


            <div class="form-row ">
                <div class="form-group col-12  col-md-6 ">
                    <label for="name">Nombre</label>
                    <input type="text" class="form-control" name="name" value="<?php echo e($categorias->name ?? ''); ?>" placeholder="Nombre" id="name" required>

                </div>
                <div class="form-group col-12  col-md-6 ">

                    <label for="state">Estado</label>
                    <select name="state" class="form-control" required>
                        <option value="1" selected>Activada</option>
                        <option value="0" >Desactivada</option>
                    </select>

                    

                </div>
                <div class="form-group col-12 ">
                    <label for="description">Descripción</label>

                    <textarea class="form-control" name="description" id="description" placeholder="Escribe una descripción" rows="3" required><?php echo e($categorias->description ?? ''); ?></textarea>
                </div>
            </div>

            <div class="form-row ">

                <div class="form-group col-12 ">
                <input type="submit" class="btn btn-primary btn-block" name="btnAgregar" value="<?php if(isset($categorias)): ?><?php echo e('Editar'); ?><?php else: ?><?php echo e('Agregar'); ?><?php endif; ?>">
                </div>
                </div>
           </div>


        </div>
    </div>
</div>
<!--Formulario de Registro-->

</div>

</form>

 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-a', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>