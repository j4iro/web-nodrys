<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Reporte pedidos completados</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/pdf.css')); ?>">
</head>
<body>
    <div class="container-fluid">

            <img class="encabezado" src="<?php echo e(asset('images/favicon/favicon.png')); ?>" width="50">
            <center>
                <strong>Historial de pedidos completados</strong>
            </center>


            <table >
                <thead class="bg-plomo">
                    <tr>
                    <th>#</th>
                    <th>Cliente</th>
                    <th>Distrito</th>
                    <th>Fecha y Hora</th>
                    <th>Ocasión</th>
                    <th>Estado</th>
                    <th>Total</th>

                    </tr>
                </thead>

                <tbody>

                    <?php $cantidad=0; ?>
                    <?php $total=0; ?>

                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente_pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $cantidad++; ?>
                            <tr>
                            <th><?php echo e($cantidad); ?></th>
                            <td><?php echo e($cliente_pedido->username); ?> <?php echo e($cliente_pedido->usersurname); ?></td>
                            <td><?php echo e($cliente_pedido->distrito); ?></td>
                            <td><?php echo e($cliente_pedido->created_at); ?></td>
                            <td><?php echo e($cliente_pedido->oca_special); ?></td>
                            <td><?php echo e($cliente_pedido->state); ?></td>
                            <td>S/. <?php echo e($cliente_pedido->total); ?></td>
                        </tr>
                        <?php $total+=$cliente_pedido->total; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>

              <table class="w-50">
                <thead class="bg-plomo">
                    <tr><th colspan="2">Resultados</th></tr>
                </thead>

                <tbody>
                    <tr>
                        <th class="text-left" >Fecha   : </th>
                        <td><?php echo e($date); ?></td>
                    </tr>
                    <tr>
                        <th class="text-left" >Suma de total:</th>
                        <td>S/. <?php echo e($total); ?></td>
                    </tr>
                    <tr>
                        <th  class="text-left">Total de registros   : </th>
                        <td><?php echo e($cantidad); ?></td>
                    </tr>

                </tbody>

            </table>

</body>
</html>
