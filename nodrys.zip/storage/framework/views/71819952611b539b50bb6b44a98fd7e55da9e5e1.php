<?php $__env->startSection('content'); ?>
            <div class="row ">
                <div class="col-12">
                <strong class="navbar-brand p-0"><?php echo e(count($restaurantes)); ?> restaurantes registrados</strong>
                </div>


            <div class="col-12 mt-2">

                    <div class="row">
                            <div class="col-12">
                                <?php if(session('resultado')): ?>
                                    <strong>
                                        <div class="alert alert-success"><?php echo e(session('resultado')); ?></div>
                                    </strong>
                                <?php endif; ?>
                            </div>
                        </div>

                <table class="table table-responsive table-hover table-sm">
                    <thead class="thead-light">
                        <tr>
                        <th scope="col">Imagen</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Estado</th>
                        <th scope="col">Slogan</th>
                        <th scope="col">Dirección</th>
                        <th scope="col">Puntos</th>
                        <th scope="col">Categoria</th>
                        <th scope="col">Distrito</th>
                        <th scope="col" colspan="2">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $restaurantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restaurant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row">
                                <img src="<?php echo e(route('restaurant.image',['filename'=>$restaurant->image])); ?>" width="50" class="img-fluid img-thumbnail shadow-sm avatar">
                            </th>
                            <td><?php echo e($restaurant->name); ?></td>
                            <th scope="col">
                                <?php if($restaurant->state==1): ?>
                                    Habilitado
                                <?php else: ?>
                                <strong class="text-danger">Deshabilitado</strong>
                                <?php endif; ?>
                            </th>
                            <td><?php echo e($restaurant->slogan); ?></td>
                            <td><?php echo e($restaurant->address); ?></td>
                            <td><?php echo e($restaurant->points); ?></td>
                            <td><?php echo e($restaurant->categoria); ?></td>
                            <td><?php echo e($restaurant->distrito); ?></td>

                            <td>
                                <a href="<?php echo e(route('admin.restaurant.edit',["id" => $restaurant->id ])); ?>" class="btn btn-outline-primary btn-sm">
                                    Editar
                                </a>
                            </td>

                            <td>
                                <?php if($restaurant->state==1): ?>
                                    <a href="<?php echo e(route('admin.restaurantes.update.state',["id" => $restaurant->id ])); ?>" class="btn btn-outline-danger btn-sm">Deshabilitar</a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('admin.restaurantes.update.state',["id" => $restaurant->id ])); ?>" class="btn btn-outline-success btn-sm">Habilitar</a>
                                <?php endif; ?>
                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>

            </div>
        </div>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-a', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>