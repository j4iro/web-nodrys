<?php $__env->startSection('content'); ?>



 <form action="<?php echo e(route('adminRestaurant.plato.save')); ?>" method="post" enctype="multipart/form-data">

    <div class="card shadow p-4 ">

        <div class="row">
            <dt class="col-12">
                <?php if(isset($plato)): ?>
                    Editar Plato
                    <input type="hidden" name="editar" value="editar">
                    <input type="hidden" name="id" value="<?php echo e($plato->id ?? ''); ?>">
                <?php else: ?>
                    Nuevo plato
                    <input type="hidden" name="editar" value="agregar">
                <?php endif; ?>


                <hr>
            </dt>
        </div>
        <div class="row">
            <div class="col-12">
                <?php if(session('resultado')): ?>
                    <strong>
                        <div class="alert alert-success"><?php echo e(session('resultado')); ?></div>
                    </strong>
                <?php endif; ?>
            </div>
        </div>

            <?php echo e(csrf_field()); ?>


            <div class="form-row ">
                <div class="form-group col-12  col-md-6 ">
                    <label for="name">Nombre</label>
                    <input type="text" class="form-control" name="name" value="<?php echo e($plato->name ?? ''); ?>" placeholder="Nombre" id="name" required>

                </div>
                <div class="form-group col-12  col-md-6 ">
                    <label for="description">Descripción</label>
                    <input type="text" class="form-control" name="description" value="<?php echo e($plato->description ?? ''); ?>" placeholder="Descripción" id="description" required>
                </div>
            </div>

            <div class="form-row ">
                <div class="form-group col-12  col-md-6 ">
                    <label for="price">Precio</label>
                    <input type="number" class="form-control" name="price" value="<?php echo e($plato->price ?? ''); ?>" placeholder="Precio" id="price" required>
                </div>
                <div class="form-group col-12  col-md-6 ">
                    <label for="time">Tiempo</label>
                    <input type="number" class="form-control" name="time" value="<?php echo e($plato->time ?? ''); ?>" placeholder="Minutos en prepararlo" id="time" required>
                </div>
            </div>

            <div class="form-row ">
                <div class="form-group col-12  col-md-6 ">
                    <label for="image">Imagen</label>
                    <input type="file" class="form-control-file" name="image" id="image"  <?php if(!isset($plato)): ?> <?php echo e('required'); ?> <?php endif; ?> >
                </div>
                <div class="form-group col-12  col-md-6 ">
                    <label for="type">Tipo</label>
                    <select class="form-control" name="category_dish" id="type">

                        
                            <option value="1" >Segundo</option>
                            <option value="2" >Entrada</option>
                            <option value="3" >Bebida</option>
                        


                    </select>
                </div>
            </div>

            <div class="form-row ">
                <div class="form-group col-12  col-md-6">
                    <input type="hidden" class="form-control" name="restaurant_id" value="1" id="">
                </div>
            </div>

            <div class="form-row ">
                <?php if(isset($plato)): ?>
                    <div class="form-group col-12 col-md-6">
                        <img src="<?php echo e(route('dish.image',['filename'=>$plato->image])); ?>" class="img-thumbnail shadow" width="70">
                    </div>
                <?php endif; ?>
                <div class="form-group col-12  col-md-6">
                <input type="submit" class="btn btn-primary btn-block" name="btnAgregar" value="<?php if(isset($plato)): ?><?php echo e('Editar'); ?><?php else: ?><?php echo e('Agregar'); ?><?php endif; ?>">
                    </div>
                </div>
            </div>




        </div>
    </form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-r', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>