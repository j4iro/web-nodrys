<?php $__env->startSection('content'); ?>
            <div class="row ">
                <div class="col-12">
                <strong class="navbar-brand p-0"><?php echo e(count($distritos)); ?> distritos registrados</strong>
                </div>


            <div class="col-12 mt-2">

                <div class="row">
                    <div class="col-12">
                        <?php if(session('resultado')): ?>
                            <strong>
                                <div class="alert alert-success"><?php echo e(session('resultado')); ?></div>
                            </strong>
                        <?php endif; ?>
                        <?php if(session('error')): ?>
                            <strong>
                                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                            </strong>
                        <?php endif; ?>
                    </div>
                </div>

                <table class="table table-responsive table-hover">
                    <thead class="thead-light">
                        <tr>
                        <th scope="col">Nombre</th>
                        <th scope="col">Estado</th>
                        <th scope="col">Descripción</th>
                        <th scope="col">Fecha de creación</th>
                        <th scope="col">Última actualización</th>
                        <th scope="col" colspan="2">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $distritos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $distrito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($distrito->name); ?></td>
                            <th scope="col">
                                <?php if($distrito->state==1): ?>
                                    Habilitado
                                <?php else: ?>
                                <strong class="text-danger">Deshabilitado</strong>
                                <?php endif; ?>
                            </th>
                            <td><?php echo e($distrito->description); ?></td>
                            <td><?php echo e($distrito->created_at); ?></td>
                            <td><?php echo e($distrito->updated_at); ?></td>

                            <td>
                                <a href="<?php echo e(route('admin.distritos.show',["id" => $distrito->id ])); ?>" class="btn btn-outline-primary btn-sm">
                                    
                                    Editar
                                </a>
                            </td>
                            <td>
                                <?php if($distrito->state==1): ?>
                                    <a href="<?php echo e(route('admin.distritos.update.state',["id" => $distrito->id ])); ?>" class="btn btn-outline-danger btn-sm">Deshabilitar</a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('admin.distritos.update.state',["id" => $distrito->id ])); ?>" class="btn btn-outline-success btn-sm">Habilitar</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>

            </div>
        </div>

 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-a', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>