<?php $__env->startSection('content'); ?>
            <div class="row">
                <div class="col-12">
                    <strong class="navbar-brand p-0">Reportes de Clientes</strong>
                </div>
            </div>
            <div class="row">
                <div class="col-4">
                    <select name="" class="form-control" id="">
                        <option value=""></option>
                    </select>
                </div>
                <div class="col-2">
                    <button type="submit" class="btn btn-primary">Filtro</button>
                </div>
            </div>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-r', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>