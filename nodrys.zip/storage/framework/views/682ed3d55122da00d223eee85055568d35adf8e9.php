<?php $__env->startSection('content'); ?>

            <!--Titulo-->
            <div class="row mb-2">
                <div class="col-12 ">
                    <strong class="navbar-brand p-0">Pedidos Completados</strong>
                </div>
            </div>
            <!--Titulo-->

            <table class="table table-responsive table-hover">
                <thead class="thead-light">
                    <tr>
                    <th scope="col">Cliente</th>
                    <th scope="col">Celular</th>
                    <th scope="col">Fecha</th>
                    <th scope="col">Hora</th>
                    <th scope="col">Ocasión Especial</th>
                    <th scope="col">N° Personas</th>
                    <th scope="col">Total</th>
                    <th scope="col">Estado</th>
                    <th scope="col">Detalles</th>
                    </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($pedido->name .' '. $pedido->surname); ?></th>
                        <td><?php echo e($pedido->telephone); ?></td>
                        <td><?php echo e($pedido->date); ?></td>
                        <td><?php echo e($pedido->hour); ?></td>
                        <td class="text-capitalize"><?php echo e($pedido->oca_special); ?></td>
                        <td><?php echo e($pedido->n_people); ?></td>
                        <td><?php echo e($pedido->total); ?></td>
                        <?php if($pedido->state=='pendiente'): ?>
                            <td class="text-danger text-uppercase"><span class="badge badge-danger"><?php echo e($pedido->state); ?></span></td>
                        <?php else: ?>
                            <td class="text-success text-uppercase"><span class="badge badge-success"><?php echo e($pedido->state); ?></span></td>
                        <?php endif; ?>

                        <td><a href="<?php echo e(route('adminRestaurant.pedidos.detail',["id"=>$pedido->id])); ?>" class="btn btn-outline-primary btn-sm">Detalles</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-r', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>