 

<?php $__env->startSection('content'); ?> 
<div class="container mt-3">
    <div class="row">
        <div class="col-12">
            <h3>Seccion principal de mantenimiento del restaurante</h3>
            <a href="<?php echo e(route('adminrestaurant.add')); ?>" class="btn btn-primary mt-2">Agregar Plato</a><br>
            <a href="" class="btn btn-primary mt-2">Ver Pedidos Pendientes</a><br>
            <a href="" class="btn btn-primary mt-2">Ver Pedidos Completados</a><br>
            <a href="" class="btn btn-primary mt-2">Datos de mi cuenta</a><br>
            <a href="" class="btn btn-primary mt-2">Escanear el QR</a><br>
            <a href="" class="btn btn-primary mt-2">Reportes</a><br>
        </div>
    </div>
</div>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>