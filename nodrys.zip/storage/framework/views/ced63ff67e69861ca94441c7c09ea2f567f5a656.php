
<ul id="myUL" class="col-12 col-md-3 col-lg-2 mb-3 ">
  <li class="btn-group dropright ">
    <span class="caret list-group-item list-group-item-action dropdown-toggle">Solicitudes</span>
    <ul class="nested dropdown-menu">
        <a href="<?php echo e(route('admin.index')); ?>" class="dropdown-item">Nuevas</a>
        <a href="<?php echo e(route('admin.solicitudes.aceptadas')); ?>" class="dropdown-item">Aceptadas</a>
        <a href="<?php echo e(route('admin.solicitudes.historial')); ?>" class="dropdown-item">Todas</a>
    </ul>
  </li>
  <li class="btn-group dropright ">
      <span class="caret list-group-item list-group-item-action dropdown-toggle">Restaurantes</span>
      <ul class="nested dropdown-menu">
          <a href="<?php echo e(route('admin.restaurants')); ?>" class="dropdown-item">
              Listar
              
          </a>
          <a href="<?php echo e(route('admin.restaurant.new')); ?>" class="dropdown-item">
              Agregar
          </a>
      </ul>
  </li>
  
  <li class="btn-group dropright">
      <span class="caret list-group-item list-group-item-action dropdown-toggle">Reportes</span>
      <ul class="nested dropdown-menu">
          <a class="dropdown-item" href="<?php echo e(route('admin.reportes')); ?>">Predeterminados</a>
          <a class="dropdown-item" href="<?php echo e(route('admin.reportespersonalizados')); ?>">Pedidos</a>
          <a class="dropdown-item" href="<?php echo e(route('admin.reportespersonalizados')); ?>">Clientes</a>
      </ul>
  </li>
  <li class="btn-group dropright">
      <span class="caret list-group-item list-group-item-action dropdown-toggle">Categorias</span>
      <ul class="nested dropdown-menu">
          <a class="dropdown-item" href="<?php echo e(route('admin.categorias.list')); ?>">Listar</a>
          <a class="dropdown-item" href="<?php echo e(route('admin.categorias.create')); ?>">Agregar</a>
      </ul>
  </li>
  <li class="btn-group dropright">
      <span class="caret list-group-item list-group-item-action dropdown-toggle">Distritos</span>
      <ul class="nested dropdown-menu">
          <a class="dropdown-item" href="<?php echo e(route('admin.distritos.list')); ?>">Listar</a>
          <a class="dropdown-item" href="<?php echo e(route('admin.distritos.new')); ?>">Agregar</a>
      </ul>

  </li>
  <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
  document.getElementById('logout-form').submit();"  class="list-group-item list-group-item-action text-danger"><strong>Salir</strong></a>
  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
      <?php echo csrf_field(); ?>
  </form>
</ul>
