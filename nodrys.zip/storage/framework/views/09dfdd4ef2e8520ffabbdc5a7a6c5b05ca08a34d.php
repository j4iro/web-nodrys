<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Reporte</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/pdf.css')); ?>">
    <style>

        /* @import  url('https://fonts.googleapis.com/css?family=Acme'); */

        h1, h3
        {
            font-family: Arial, Helvetica, sans-serif;
        }

        .table
        {
            font-size: 0.85rem;
        }

        .encabezado
        {
            position: fixed;
        }

        .table-resultados
        {
            width: 35%;
        }

        body
        {
            background: white;
        }

    </style>
</head>
<body>
    <div class="container-fluid">

        <div class="row ">
            <div class="col-6 ">
                <img class="encabezado" src="<?php echo e(asset('images/favicon/favicon.png')); ?>" width="50">
            </div>
        </div>

        <div class="row mt-3">
            <div class="col-12 text-center">
                <strong>Historial de pedidos</strong>
            </div>
        </div>

            <table class="table table-sm mt-5">
                <thead class="thead-light ">
                    <tr>
                    <th>#</th>
                    <th>Cliente</th>
                    <th>Distrito</th>
                    <th>Fecha y Hora</th>
                    <th>Ocasión</th>
                    <th>Estado</th>
                    <th>Total</th>

                    </tr>
                </thead>

                <tbody>

                    <?php $cantidad=0; ?>
                    <?php $total=0; ?>

                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente_pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $cantidad++; ?>
                            <tr>
                            <td><?php echo e($cantidad); ?></td>
                            <td><?php echo e($cliente_pedido->username); ?> <?php echo e($cliente_pedido->usersurname); ?></td>
                            <td><?php echo e($cliente_pedido->distrito); ?></td>
                            <td><?php echo e($cliente_pedido->created_at); ?></td>
                            <td><?php echo e($cliente_pedido->oca_special); ?></td>
                            <td><?php echo e($cliente_pedido->state); ?></td>
                            <td>S/. <?php echo e($cliente_pedido->total); ?></td>
                        </tr>
                        <?php $total+=$cliente_pedido->total; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>

              <table class="table table-sm mt-5 table-resultados">
                <thead class="thead-light ">
                    <tr>
                        <th colspan="2">Resultados</th>
                    </tr>
                </thead>

                <tbody>
                    <tr>
                        <td ><strong>Fecha   : </strong></td>
                        <td><strong><?php echo e($date); ?></strong></td>
                    </tr>
                    <tr>
                        <td ><strong>Suma de total:</strong></td>
                        <td><strong>S/. <?php echo e($total); ?></strong></td>
                    </tr>
                    <tr>
                        <td ><strong>Total de registros   : </strong></td>
                        <td><strong><?php echo e($cantidad); ?></strong></td>
                    </tr>

                </tbody>

            </table>

</body>
</html>
