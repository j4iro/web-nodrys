<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PDF Laravel</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/pdf.css')); ?>">
    <style>
        
        /* @import  url('https://fonts.googleapis.com/css?family=Acme'); */

        h1
        {
            font-family: Arial, Helvetica, sans-serif;
        }

        .row4
        {
            display: flex;
            justify-content: space-around;
        }

        .encabezado
        {
            position: fixed;
        }
        
    </style>
</head>
<body>
    <div class="container-fluid">
        
        <div class="row ">
            <div class="col-6 ">
                <img class="encabezado" src="<?php echo e(asset('images/favicon/favicon.png')); ?>" width="50">
            </div>
           
        </div>


        <h1>Titulo</h1>

        <div class="alert alert-success">
            Great
        </div>

        <table class="table">
                <thead class="thead-dark">
                  <tr>
                    <th>#</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                  </tr>
                </thead>
                <tbody>
                    <?php for($i = 0; $i < 50; $i++): ?>
                        
                    <tr>
                        <th scope="row">1</th>
                        <td>Mark</td>
                        <td>Otto</td>
                    </tr>
                    <?php endfor; ?>
                 
                </tbody>
              </table>
              
    </div>
</body>
</html> 