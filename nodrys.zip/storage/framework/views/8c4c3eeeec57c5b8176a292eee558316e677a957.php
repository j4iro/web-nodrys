<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Reporte</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/pdf.css')); ?>">
</head>
<body>
    <div class="container-fluid">
    <img class="encabezado" src="<?php echo e(asset('images/favicon/favicon.png')); ?>" width="50">
    <center>
        <strong >Reporte Clientes Registrados</strong>
    </center>

        <table >
            <thead class="bg-plomo">
                <tr>
                <th>#</th>
                <th>Cliente</th>
                <th>Dirección</th>
                <th>Celular</th>
                <th>Distrito</th>
                <th>F. Registro</th>
                </tr>
            </thead>

            <tbody>

                <?php $cantidad=0; ?>

                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $cantidad++; ?>
                        <tr>
                        <th><?php echo e($cantidad); ?></th>
                        <td><?php echo e($cliente->name); ?> <?php echo e($cliente->surname); ?></td>
                        <td><?php echo e($cliente->email); ?></td>
                        <td><?php echo e($cliente->telephone); ?></td>
                        <td><?php echo e($cliente->distrito); ?></td>
                        <td class="text-center"><?php echo e(substr($cliente->created_at,0,10)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>

    <table class="w-50" >
        <thead class="bg-plomo" >
            <tr><th colspan="2">Resultados</th></tr>
        </thead>

        <tbody>
            <tr>
                <th class="text-left" >Fecha de impresión  :</th>
                <td><?php echo e($date); ?></td>
            </tr>
            <tr>
                <th class="text-left" >Total de registros   : </th>
                <td><?php echo e($cantidad); ?></td>
            </tr>
        </tbody>

    </table>

</body>
</html>
