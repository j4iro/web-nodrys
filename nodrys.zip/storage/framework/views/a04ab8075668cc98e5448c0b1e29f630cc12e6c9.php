<?php $__env->startSection('content'); ?> 

<div class="container mt-3">

        <div class="row">
            <div class="col-12">
                <h3>Agregar un nuevo plato</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <?php if(session('i')): ?>
                    <div class="alert alert-success"><?php echo e(session('i')); ?> </div>
                <?php endif; ?>
            </div>
        </div>

    <form action="<?php echo e(route('adminRestaurant.add')); ?>" method="post">
        <?php echo e(csrf_field()); ?>


        <div class="row mt-3">
            <div class="col-4">
                <input type="text" class="form-control" name="name" placeholder="Nombre" id="">
            </div>
            <div class="col-4">
                <input type="text" class="form-control" name="description" placeholder="Descripcion" id="">
            </div>
        </div>

        <div class="row mt-3">
            <div class="col-4">
                <input type="text" class="form-control" name="price" placeholder="Precio" id="">
            </div>
            <div class="col-4">
                <input type="text" class="form-control" name="time" placeholder="Tiempo" id="">
            </div>
        </div>

        <div class="row mt-3">
            <div class="col-4">
                <input type="file" class="form-control-file" value="txts" name="image"  id="">
            </div>
            <div class="col-4">
                    <input type="text" class="form-control" name="restaurant_id"  id="">
             </div>
             <div class="col-4">
                    <input type="text" class="form-control" name="type" value="segundo"  id="">
             </div>
        </div>

        <div class="row mt-3">
            <div class="col-4">
                <input type="submit" class="btn btn-primary" name="btnAgregar" value="Agregar">
            </div>
        </div>

                    
        </form>


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>