<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Reporte</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/pdf.css')); ?>">
</head>
<body>
    <div class="container-fluid">


                <img class="encabezado" src="<?php echo e(asset('images/favicon/favicon.png')); ?>" width="50">


                <center>
                    <strong >Reporte Restaurantes por Distrito</strong>
                </center>


            <table >
                <thead >
                    <tr class="bg-plomo">
                    <th>#</th>
                    <th>Distrito</th>
                    <th>Nombre</th>
                    <th>Dirección</th>
                    <th>Ingreso</th>
                    </tr>
                </thead>

                <tbody>

                    <?php $cantidad=0; ?>

                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restaurant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $cantidad++; ?>
                        <tr>
                            <th><?php echo e($cantidad); ?></th>
                            <td><?php echo e($restaurant->distrito); ?></td>
                            <td><?php echo e($restaurant->name); ?></td>
                            <td><?php echo e($restaurant->address); ?></td>
                            <td class="text-center"><?php echo e(substr($restaurant->created_at,0,10)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>

            <table class="w-50">
                <thead class="bg-plomo" >
                    <tr>
                        <th colspan="2">Resultados</th>
                    </tr>
                </thead>

                <tbody >
                    <tr>
                        <td>Fecha de impresión :</td>
                        <td><?php echo e($date); ?></td>
                    </tr>

                    <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($data->distrito); ?></td>
                            <td><?php echo e($data->total); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>

            </table>

</body>
</html>
