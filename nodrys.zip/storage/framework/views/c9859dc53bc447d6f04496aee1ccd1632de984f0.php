<!DOCTYPE html>

<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>
        <?php echo $__env->yieldContent('title'); ?>
    </title>

    <!-- Scripts -->
    

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">

    <!-- Favicon -->
    <link rel="icon" type="image/png"  href="<?php echo e(asset('images/favicon/favicon.png')); ?>">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('scripts'); ?>
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light navbar-laravel sticky-top">
            <div class="container">
                <a class="navbar-brand p-0" href="<?php echo e(url('/')); ?>">
                    
                    <img class="p-0 img-fluid" src="<?php echo e(asset('svg/logo.svg')); ?>" width="40" alt="Nodrys">
                    <strong>Nodrys</strong>

                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('home')); ?>"  class="nav-link">Restaurantes</a>
                            </li class="nav-item">
                            <li class="nav-item">
                                <a href="<?php echo e(route('getAllDishes')); ?>"  class="nav-link">Platos</a>
                            </li class="nav-item">
                            <li>
                                <a href="<?php echo e(route('carrito.index')); ?>"  class="nav-link">Mi Carrito
                                    <?php if(isset($_SESSION['carrito']) && count($_SESSION['carrito'])>=1): ?>
                                        <span class="badge badge-warning "><?php echo e(count($_SESSION['carrito'])); ?></span>
                                    <?php else: ?>
                                        <span class="badge badge-warning">0</span>
                                    <?php endif; ?>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Iniciar Sesión')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Registrarse')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('home')); ?>"  class="nav-link">Restaurantes</a>
                            </li class="nav-item">
                            <li class="nav-item">
                                <a href="<?php echo e(route('getAllDishes')); ?>"  class="nav-link">Platos</a>
                            </li class="nav-item">
                            <li>
                                <a href="<?php echo e(route('carrito.index')); ?>"  class="nav-link">Mi Carrito
                                    <?php if(isset($_SESSION['carrito']) && count($_SESSION['carrito'])>=1): ?>
                                        <span class="badge badge-warning "><?php echo e(count($_SESSION['carrito'])); ?></span>
                                    <?php else: ?>
                                        <span class="badge badge-warning">0</span>
                                    <?php endif; ?>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('pedidos.index')); ?>"  class="nav-link">Mis Pedidos
                                    
                                </a>
                            </li>
                            <li>
                                
                            </li>



                            <li>
                                <?php if(auth()->user()->hasRoles(['admin'])): ?>
                                        <a target="_blank" href="<?php echo e(route('admin.index')); ?>" class="nav-link">Panel Administrador Master</a>
                                <?php endif; ?>
                            </li>
                            <li>
                                <?php if(auth()->user()->hasRoles(['admin-restaurant'])): ?>
                                        <a target="_blank" href="<?php echo e(route('adminRestaurant.index')); ?>" class="nav-link">Restaurant administrator</a>
                                <?php endif; ?>
                            </li>


                            <li class="ml-0 ml-sm-3">
                                <?php echo $__env->make('includes.avatar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </li>

                            

                            <li>
                                <a  href="<?php echo e(route('config')); ?>" class="nav-link"><?php echo e(Auth::user()->name); ?></a>
                            </li>

                            <li>
                                <a class="nav-link text-danger" href="<?php echo e(route('logout')); ?>"
                                  onclick="event.preventDefault();
                                      document.getElementById('logout-form').submit();">
                                   <img src="<?php echo e(asset('images/icons/icon-exit.png')); ?>" width="20">
                               </a>
                               <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                   <?php echo csrf_field(); ?>
                               </form>
                          </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="p-0">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>
</html>
