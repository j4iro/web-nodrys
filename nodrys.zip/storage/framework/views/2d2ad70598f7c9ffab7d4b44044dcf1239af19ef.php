<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.4.0.min.js"></script>
    <script type="text/javascript">

    window.onload=function () {
        var t = setInterval(function(){
            // post::()
            // notificar('uno','genial');
        }, 3000);
    };
    document.addEventListener("DOMContentLoaded",function() {
        if (!Notification) {
            alert("Las notificaciones no estan soportadas en tu navegador")
            return
        }
        if(Notification.permission!=="granted")
            Notification.requestPermission()
    });

    function notificar(titulo,mensaje) {
        if (Notification.permission!=="granted") {
            Notification.requestPermission();
        }else {
            var notificacion=new Notification(titulo,{
                icon:"<?php echo e(asset('images/favicon/favicon.png')); ?>",
                body:mensaje
            });
            notificacion.onclick=function(){
                window.open("/");
            }
        }
    }



    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
            <div class="row ">
            <div class="col-12">
                <strong class="navbar-brand p-0"><?php echo e(count($solicitudes) . $titulo); ?></strong>
            </div>

            <div class="col-12 mt-2">

                <table class="table table-responsive table-hover">
                    <thead class="thead-light">
                        <tr>
                        <th scope="col">Código</th>
                        <th scope="col" colspan="2">Restaurante</th>
                        <th scope="col">Estado</th>
                        <th scope="col">Fecha y hora de registro</th>
                        <th scope="col">Email</th>
                        <th scope="col">Telefono</th>
                        <th scope="col">Puntos</th>
                        <th scope="col">Categoria</th>
                        <th scope="col">Distrito</th>
                        <th scope="col">Opciones</th>
                        </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $solicitudes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solicitud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"> SOL-<?php echo e($solicitud->id); ?></th>
                            <th scope="row">
                                <img src="<?php echo e(route('restaurant.image',['filename'=>$solicitud->image])); ?>" width="50" class="img-fluid img-thumbnail shadow-sm avatar">
                            </th>
                            <td><?php echo e($solicitud->name); ?></td>
                            <td>
                                <?php if($solicitud->state==1): ?>
                                    <strong class="text-danger">Nueva</strong>
                                <?php else: ?>
                                    <strong class="text-primary">Atendida</strong>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($solicitud->created_at); ?></td>
                            <td><?php echo e($solicitud->email); ?></td>
                            <td><?php echo e($solicitud->telephone); ?></td>
                            <td><?php echo e($solicitud->points); ?></td>
                            <td><?php echo e($solicitud->categoria); ?></td>
                            <td><?php echo e($solicitud->distrito); ?></td>

                            <td>
                                <a href="<?php echo e(route('admin.restaurant.show-solicitud',["id" => $solicitud->id ])); ?>" class="btn btn-outline-primary btn-sm">
                                    Ver
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>

            </div>
        </div>
        
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-a', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>