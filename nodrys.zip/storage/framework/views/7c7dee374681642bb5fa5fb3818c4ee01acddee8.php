<?php $__env->startSection('content'); ?>

        <!--Titulo-->
        <div class="row mb-2">
            <div class="col-12 ">
                <strong class="navbar-brand p-0">Mis platos a ofrecer</strong>
            </div>
        </div>
        <!--Titulo-->

        <?php if(session('resultado')): ?>
            <div class="row mb-2">
                <div class="col-12">
                    <strong><div class="alert alert-success"><?php echo e(session('resultado')); ?></div></strong>
                </div>
            </div>
        <?php endif; ?>

            <table class="table table-responsive table-hover">
                <thead class="thead-light">
                    <tr>
                        <th scope="col">Imagen</th>
                        <th scope="col">Tipo</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Descripción</th>
                        <th scope="col">Precio</th>
                        <th scope="col">Tiempo</th>
                        <th scope="col">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $dishes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dish): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <img src="<?php echo e(route('dish.image',['filename'=>$dish->image])); ?>" class="img-thumbnail " width="50">
                        </td>
                        <td class="text-capitalize"><?php echo e($dish->type); ?></td>
                        <td><?php echo e($dish->name); ?></td>
                        <td><?php echo e($dish->description); ?></td>
                        <td><?php echo e($dish->price); ?></td>
                        <td><?php echo e($dish->time); ?></td>
                        <td>
                            <div class="btn-group" role="group" aria-label="Basic example">
                                <a href="<?php echo e(route('adminRestaurant.plato.edit',["id" => $dish->id ])); ?>" class="btn btn-outline-primary btn-sm">
                                    <img src="https://img.icons8.com/ultraviolet/40/000000/edit.png" width="18">
                                </a>
                                <a href="<?php echo e(route('adminRestaurant.plato.delete',["id" => $dish->id ])); ?>" class="btn btn-outline-danger btn-sm">
                                    <img src="https://img.icons8.com/color/48/000000/cancel.png"  width="18">
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </tbody>
            </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-r', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>