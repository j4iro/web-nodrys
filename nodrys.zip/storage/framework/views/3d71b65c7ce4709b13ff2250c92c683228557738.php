<?php $__env->startSection('scripts'); ?>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.4.0/dist/leaflet.css"
       integrity="sha512-puBpdR0798OZvTTbP4A8Ix/l+A4dHDD0DGqYW6RQ+9jxkRFclaxxQb/SJAWZfWAkuyeQUytO7+7N4QKrDh+drA=="
       crossorigin=""/>
     <script src="https://unpkg.com/leaflet@1.4.0/dist/leaflet.js"
      integrity="sha512-QVftwZFqvtRNi0ZyCtsznlKSWOStnDORoefr1enyq5mVL4tmKB3S/EnC3rRJcxCPavG10IcrVGSmPh6Qw5lwrg=="
      crossorigin=""></script>
      <style media="screen">
          #map{
              width: 80%;
              height: 400px;

          }
          .hubicacion_controls{
              display: none;
          }
          .btnActual{
              position: absolute;
              z-index: 99;
              right: 0;
          }
          .map_container{
            position: relative;
          }
      </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('admin.restaurant.save')); ?>" method="post" enctype="multipart/form-data">
    <div class="card shadow p-4 ">

        <div class="row">
            <dt class="col-12">
                <?php if(isset($restaurante) && !isset($solicitud)): ?>
                    Editar Restaurante

                    <input type="hidden" name="editar" value="editar">
                    <input type="hidden" name="id" value="<?php echo e($restaurante->id ?? ''); ?>">
                <?php else: ?>
                    Nuevo Restaurante
                    <input type="hidden" name="editar" value="agregar">
                    <?php if(isset($solicitud)): ?>
                    <input type="hidden" name="solicitud" value="<?php echo e($solicitud); ?>" >
                    <?php endif; ?>
                <?php endif; ?>
                <hr>
            </dt>
        </div>
        <div class="row">
            <div class="col-12">
                <?php if(session('resultado')): ?>
                    <strong>
                        <div class="alert alert-success"><?php echo e(session('resultado')); ?></div>
                    </strong>
                <?php endif; ?>
                <?php if(session('error_password')): ?>
                    <strong>
                        <div class="alert alert-danger"><?php echo e(session('error_password')); ?></div>
                    </strong>
                <?php endif; ?>
            </div>
        </div>

            <?php echo e(csrf_field()); ?>


            <div class="form-row ">
                <div class="form-group col-12 col-md-6 ">
                    <label for="name">Nombre</label>
                    <input type="text" class="form-control" name="name" value="<?php echo e($restaurante->name ?? ''); ?>" placeholder="Nombre" id="name" required>

                </div>
                <div class="form-group col-12 col-md-6 ">
                    <label for="slogan">Eslogan</label>
                    <input type="text" class="form-control" name="slogan" value="<?php echo e($restaurante->slogan ?? ''); ?>" placeholder="Breve Descripción" id="slogan" required>
                </div>
            </div>

            <div class="form-row ">
                <div class="form-group col-12">
                    <label for="name">Descripción</label>
                    <textarea type="text" rows="3" class="form-control" name="description"  id="description" required><?php echo e($restaurante->description ?? ''); ?></textarea>
                </div>
            </div>

            <div class="form-row ">
                <div class="form-group col-12  col-md-6 ">
                    <label for="address">Dirección</label>
                    <input type="text" class="form-control" name="address" value="<?php echo e($restaurante->address ?? ''); ?>" placeholder="Dirección" id="address" required>
                </div>
                <div class="form-group col-12  col-md-6 ">
                    <label for="points">Puntos</label>
                    <input type="number" class="form-control" name="points" value="<?php echo e($restaurante->points ?? ''); ?>" placeholder="Puntos por reservar" id="points" required>
                </div>
            </div>

            <div class="form-row ">
                <div class="form-group col-12  col-md-6 ">
                    <label for="type">Distrito</label>
                    <select class="form-control" name="district_id" id="type">
                        <?php $__currentLoopData = $distritos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $distrito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($distrito->id); ?>" <?php if(isset($restaurante->district_id) && $distrito->id==$restaurante->district_id): ?> <?php echo e('selected'); ?> <?php endif; ?> ><?php echo e($distrito->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group col-12  col-md-6 ">
                    <label for="type">Categoria</label>
                    <select class="form-control" name="category_id" id="type">
                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($categoria->id); ?>" <?php if(isset($restaurante->category_id) && $categoria->id==$restaurante->category_id): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e($categoria->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="form-row ">
                <div class="form-group col-12  col-md-6 ">
                    <label for="telephone">Telefono - Celular</label>
                    <input type="text" class="form-control" name="telephone"  placeholder="Telefono o celular" id="telephone" value="<?php echo e($restaurante->telephone ?? ''); ?>" required  >
                </div>
                <div class="form-group col-12  col-md-6 ">
                    <label for="type"><strong>Email de ingreso</strong></label>
                    <input type="email" class="form-control" name="email_ingreso" value="<?php echo e($user->email ?? ''); ?>" placeholder="Email de acceso al panel" id="address" required>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-12  col-md-6 ">
                    <label for="address">RUC</label>
                    <input type="text" class="form-control" name="ruc" value="<?php echo e($restaurante->ruc ?? ''); ?>" placeholder="Dirección" id="ruc" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group col-12  col-md-6 ">
                    <label for="password"><strong>Contraseña</strong></label>
                    <input type="password" class="form-control" name="password" placeholder="Nueva contraseña" id="password"  <?php if(isset($restaurante) && !isset($solicitud)): ?> <?php echo e(''); ?> <?php else: ?> <?php echo e('required'); ?> <?php endif; ?> >

                </div>
                <div class="form-group col-12  col-md-6 ">
                    <label for="repeatpassword"><strong>Repita la Contraseña</strong></label>
                    <input type="password" class="form-control <?php if(session('error_password')): ?> <?php echo e('is-invalid'); ?> <?php endif; ?>" name="repeatpassword"  placeholder="Repita la contraseña" id="repeatpassword" <?php if(isset($restaurante) && !isset($solicitud)): ?> <?php echo e(''); ?> <?php else: ?> <?php echo e('required'); ?> <?php endif; ?> >
                    <div class="invalid-feedback" >
                        <strong>Las contraseñas no coinciden</strong>
                    </div>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group col-12  col-md-6 ">
                    <label for="address">Latitud</label>
                    <input type="text" class="form-control" name="latitud" value="<?php echo e($restaurante->latitude?? ''); ?>" placeholder="Dirección" id="latitud" required>
                </div>
                <div class="form-group col-12  col-md-6 ">
                    <label for="address">Longitud</label>
                    <input type="text" class="form-control" name="longitud" value="<?php echo e($restaurante->longitude ?? ''); ?>" placeholder="Dirección" id="longitud" required>
                </div>
            </div>
            <div class="form-group container">
                    <div class="hubicacion_controls">
                      Latitud : <input type="text" name="txtlati" id="txtlati">
                      longitud : <input type="text" name="txtlong" id="txtlong">
                    </div>

                    <center>
                        <div class="map_container">
                            <div id="map">

                            </div>
                            <button class="btn btn-primary" type="button" class="btnActual" name="button" onclick="localizar()">Ubicacion Actual</button>
                        </div>

                    </center>
            </div>



            <hr>

            <div class="form-row d-flex justify-content-center ">
                <div class="form-group col-12 col-md-5 text-center shadow-sm border  p-2 rounded">
                    <label for="image"><strong>Imagen</strong></label>
                    <input type="file" class="form-control-file" name="image" id="image"  <?php if(!isset($restaurante)): ?> <?php echo e('required'); ?> <?php endif; ?> >
                </div>
            </div>

            <div class="form-row d-flex justify-content-center">
                <?php if(isset($restaurante)): ?>
                    <div class="form-group col-12 col-md-5">
                        <img src="<?php echo e(route('restaurant.image',['filename'=>$restaurante->image])); ?>" class="img-thumbnail shadow" width="100%">
                        <?php if(isset($solicitud)): ?>
                            <input type="hidden" class="form-control-file" name="imagen_soli" id="image"  value="<?php echo e($restaurante->image); ?>" >
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <div class="form-row d-flex justify-content-center">
                <div class="form-group col-12 col-md-5">
                    <input type="submit" class="btn btn-primary btn-block" id="guardar" name="btnAgregar" value="Guardar">
                </div>
            </div>



        </div>

</form>

<script>

            var txtnombre=document.getElementById('name').value;
            var txtLati=document.getElementById('latitud');
            var txtLong=document.getElementById('longitud');

            var lati=parseFloat(txtLati.value);
            var long=parseFloat(txtLong.value);

            var marker=L.marker();

            var map = L.map('map');
             L.tileLayer('http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                 attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="http://cloudmade.com">CloudMade</a>',
                 maxZoom: 18
             }).addTo(map);


             ubicaionRes();

             function ubicaionRes(){
                 map.setView([lati,long],15);
                 map.removeLayer(marker);
                 marker = L.marker([lati,long], {draggable: true}).addTo(map);
                  marker.on('drag', onMapClic);
             }

            function onMapClic(e) {
                console.log(e);
                    txtLati.value=e.latlng.lat;
                    txtLong.value=e.latlng.lng;
            }



         </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-a', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>