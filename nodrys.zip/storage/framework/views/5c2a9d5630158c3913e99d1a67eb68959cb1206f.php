<?php $__env->startSection('content'); ?>

<?php if(session('vacio')): ?>
    <?php echo "<script>alert('".session('vacio')."');</script>" ?>
<?php endif; ?>

<div class="container-fluid">
    <form action="<?php echo e(route('carrito.add')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

        <div class="row bg-intro d-flex justify-content-center align-items-center">
            <div class="col-12 col-sm-8 col-md-5">
                <div class="input-group mb-3">
                    <input type="text" name="name" class="form-control form-control-lg" placeholder="¿Qué se te antoja comer hoy?" >
                    <div class="input-group-append">
                        <button class="btn btn-primary btn-lg" name="buscar" type="submit">Buscar</button>
                    </div>
                </div>
            </div>
        </div>

    </form>
</div>


<div class="container my-4">

    <div class="row">
        <div class="col-12 ">
            <strong class="navbar-brand">Busca entre <?php echo e(count($platos)); ?> platos para tí</strong>
        </div>
    </div>

    <?php if(isset($resultado)): ?>
        <div class="row">
            <div class="col-12 ">
                <div class="alert alert-success">
                        <strong> <?php echo e($resultado); ?> <a href="<?php echo e(route('getAllDishes')); ?>">Ver todos</a></strong>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('carrito.add')); ?>" method="post">
    <?php echo e(csrf_field()); ?>

    <div class="row mt-1">
        <?php $__currentLoopData = $platos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dish): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-6 col-md-4 col-lg-2 mb-4">
            <div class="card card-plato">
                <?php echo $__env->make('includes.image_dish', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="card-body p-0 px-3 pt-2 pb-3">
                    <h5 class="card-title card-title-plato mb-1"><?php echo e($dish->name); ?></h5>
                    <p class="card-text card-text-plato m-0"><?php echo e($dish->restaurante); ?> </p>
                    <p class="card-text card-text-plato m-0"><?php echo e($dish->time); ?> Min.</p>
                    <p class="card-text card-text-plato m-0">S/. <?php echo e($dish->price); ?></p>
                    <input class="form-check-input" type="checkbox" value="<?php echo e($dish->id); ?>" name="checkDish[]" >
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="row">
        <div class="col-3">
            
            <input type="submit" class="btn btn-primary"  name="addcarrito" value="Añadir al carrito">
        </div>
    </div>
    </form>


</div>

<?php echo $__env->make('includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>