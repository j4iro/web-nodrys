<?php $__env->startSection('content'); ?>
<div class="container">

    <div class="row mt-3">
        <div class="col-12 ">
            <h2>Mis Restaurantes o platos favoritos</h2>
        </div>
    </div>

    



</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>