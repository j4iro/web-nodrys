<?php $__env->startSection('content'); ?>

<div class="container mt-4 ">
        <div class="row justify-content-center">
            <div class="col-md-8">

                <?php if(session('message')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>¡Genial!</strong> Tus datos se han actualizado correctamente.
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>

                <?php if(session('error_password_no_coinciden')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <strong>¡Opss!</strong> Las contraseñas no coinciden, vuelve a intentarlo.
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>

                <div class="card shadow mb-5">
                    <div class="card-header text-center"><img class="mb-1 mr-1" src="https://img.icons8.com/ios-glyphs/24/000000/user.png" width="18" ><strong>Mi perfil</strong></div>

                    <div class="card-body">
                    <form method="POST" action="<?php echo e(route('user.update')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="form-group row">
                                <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nombres')); ?></label>

                                <div class="col-md-6">
                                    <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(Auth::user()->name); ?>" required autofocus>

                                    <?php if($errors->has('name')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="surname" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Apellidos')); ?></label>

                                <div class="col-md-6">
                                    <input id="surname" type="text" class="form-control<?php echo e($errors->has('surname') ? ' is-invalid' : ''); ?>" name="surname" value="<?php echo e(Auth::user()->surname); ?>" required >

                                    <?php if($errors->has('surname')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('surname')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail')); ?></label>

                                <div class="col-md-6">
                                    <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(Auth::user()->email); ?>" required >

                                    <?php if($errors->has('email')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="telephone" class="col-md-4 col-form-label text-md-right">Celular</label>

                                <div class="col-md-6">
                                    <input id="telephone" type="number" class="form-control<?php echo e($errors->has('telephone') ? ' is-invalid' : ''); ?>" name="telephone" value="<?php echo e(Auth::user()->telephone); ?>"  >

                                    <?php if($errors->has('telephone')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('telephone')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="telephone" class="col-md-4 col-form-label text-md-right">Distrito</label>

                                <div class="col-md-6">

                                    <select name="district_id" class="form-control">
                                        <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($district->id); ?>" <?php if(Auth::user()->district_id==$district->id): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e($district->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <?php if($errors->has('telephone')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('telephone')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="address" class="col-md-4 col-form-label text-md-right">Dirección</label>

                                <div class="col-md-6">
                                    <input id="address" type="text" class="form-control<?php echo e($errors->has('address') ? ' is-invalid' : ''); ?>" name="address" value="<?php echo e(Auth::user()->address); ?>"  >

                                    <?php if($errors->has('address')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('address')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label  class="col-md-4 col-form-label text-md-right">
                                    <strong style="cursor:pointer;" onclick="show_block_password();" class="text-primary">Cambiar contraseña</strong>
                                </label>
                            </div>

                            <div id="block_password" class="d-none border border-primary p-3 rounded mb-3">
                            <div class="form-group row">
                                <label for="newpassword" class="col-md-4 col-form-label text-md-right">Nueva contraseña</label>

                                <div class="col-md-6">
                                    <input id="newpassword" onkeyup="agregar_required_repeat_password();" type="text" class="form-control<?php echo e($errors->has('newpassword') ? ' is-invalid' : ''); ?>" name="newpassword" >

                                    <?php if($errors->has('newpassword')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('newpassword')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="repeatpassword" class="col-md-4 col-form-label text-md-right">Repita la contraseña</label>

                                <div class="col-md-6">
                                    <input id="repeatpassword" onkeyup="agregar_required_new_password();" type="password" class="form-control<?php echo e($errors->has('repeatpassword') ? ' is-invalid' : ''); ?>" name="repeatpassword"  >

                                    <?php if($errors->has('repeatpassword')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('repeatpassword')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            </div>

                            <div class="form-group row">
                                <label for="imagepath" class="col-md-4 col-form-label text-md-right">Foto</label>

                                <div class="col-md-6">
                                    <input id="imagepath" type="file" class="form-control-file <?php echo e($errors->has('imagepath') ? ' is-invalid' : ''); ?>" name="image_path"   >

                                    <?php if($errors->has('imagepath')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('imagepath')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row justify-content-center">
                                <div class="col-md-4">
                                    <?php echo $__env->make('includes.avatar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                </div>
                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        Guardar Cambios
                                    </button>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
     
    <script>
        function agregar_required_repeat_password()
        {
            if(newpassword.value.length!=0)
            {
                repeatpassword.required=true;
            }
            else
            {
                repeatpassword.required=false;
            }
        }
        function agregar_required_new_password()
        {
            if(repeatpassword.value.length!=0)
            {
                newpassword.required=true;
            }
            else
            {
                newpassword.required=false;
            }
        }
        function show_block_password()
        {

            if (block_password.classList.contains('d-none'))
            {
                block_password.classList.remove('d-none');
            }
            else
            {
                block_password.classList.add('d-none');
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>