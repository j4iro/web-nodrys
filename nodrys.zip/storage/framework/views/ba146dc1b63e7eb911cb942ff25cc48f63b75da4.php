<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row mt-3">
            <div class="col-12 ">
                <h4>Detalle del pedido</h4>
            </div>

            <div class="col-12">

                <table class="table table-responsive table-hover">
                    <thead class="thead-light">
                        <tr>
                        <th scope="col" colspan="2">Plato</th>
                        <th scope="col">Precio</th>
                        
                        </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row" class="p-0 pt-1 pl-2">
                                <img src="<?php echo e(route('dish.image',['filename'=>$pedido->image])); ?>" width="50" class="img-fluid img-thumbnail shadow-sm avatar">
                            </th>
                            <th scope="row"><?php echo e($pedido->name); ?></th>
                            <td><?php echo e($pedido->price); ?></td>
                            <td class="text-capitalize"><?php echo e($pedido->type); ?></td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>

            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-r', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>