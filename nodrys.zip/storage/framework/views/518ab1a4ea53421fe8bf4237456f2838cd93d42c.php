<?php $__env->startSection('content'); ?>


                <div class="col-7">
                        <div class="preview-container">
                            <video id="preview"></video>
                                <div class="cameras">
                                    <h4>Cameras</h4>
                                    <div id="camerasList">
                                    </div>
                                </div>
                            <div class="scans">
                                <div id="scans">
                                    <h4>Scans</h4>

                                </div>
                            </div>
                            <div id="line" class="line"></div>
                        </div>
                    <form style="display:none" action="<?php echo e(route('adminRestaurant.pedidos.confirmation')); ?>" method="post" display="none">
                        <?php echo csrf_field(); ?>
                        <input id="txtCode" type="text" name="txtCode" value="">
                        <button id="btnConfirma" name="btnConfirma" class="btn btn-primary">enviar</button>

                    </form>
                </div>
                <div class="col-3">
                    <?php if(session('order')): ?>
                        <?php
                            $order=session('order');
                        ?>
                        <h2>Ultima Orden confirmada</h2>
                        <table class="table">
                            <tr>
                                <td>Fecha:</td>
                                <td><?php echo e($order->date); ?></td>
                            </tr>
                            <tr>
                                <td>Hora:</td>
                                <td><?php echo e($order->hour); ?></td>
                            </tr>
                            <tr>
                                <td>N° Personas:</td>
                                <td><?php echo e($order->n_people); ?></td>
                            </tr>
                            <tr>
                                <td>Pago:</td>
                                <td><?php echo e($order->total); ?></td>
                            </tr>
                        </table>
                    <?php elseif(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/webcam/instascan.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/webcam/app.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-r', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>